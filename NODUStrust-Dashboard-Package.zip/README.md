# NODUStrust Dashboard

A secure audit dashboard for trust-based operations.

## Usage
- Start server
- Use `Fetch Audit Logs` button
- Secure API with your `AUDIT_API_KEY`